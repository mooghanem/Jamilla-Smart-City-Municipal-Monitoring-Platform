from machine import Pin
import time

entrance = Pin(34, Pin.IN)  
exit_btn = Pin(35, Pin.IN)  

leds = [
    Pin(2, Pin.OUT),   
    Pin(4, Pin.OUT),  
    Pin(5, Pin.OUT), 
    Pin(13, Pin.OUT),  
    Pin(14, Pin.OUT), 
    Pin(16, Pin.OUT), 
    Pin(17, Pin.OUT),  
    Pin(18, Pin.OUT)   
]

cars = 0  

def update_display():
    """Light up LEDs equal to car count"""
    for i in range(8):
        leds[i].value(i < cars)

def handle_press(btn):
    """Process button press with debounce"""
    global cars
    time.sleep_ms(250)  # Debounce
    
    if btn == entrance and cars < 8:
        cars += 1
        print(f"+1 Car (Total: {cars})")
    elif btn == exit_btn and cars > 0:
        cars -= 1
        print(f"-1 Car (Total: {cars})")
    
    update_display()

# Main loop
while True:
    if entrance.value(): handle_press(entrance)
    if exit_btn.value(): handle_press(exit_btn)
    time.sleep(0.1)

